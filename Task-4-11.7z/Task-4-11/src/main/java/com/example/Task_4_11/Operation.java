package com.example.Task_4_11;

public interface Operation {
    double getResult(double a, double b);
}

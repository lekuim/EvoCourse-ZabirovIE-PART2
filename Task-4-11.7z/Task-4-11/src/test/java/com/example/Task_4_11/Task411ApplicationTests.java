package com.example.Task_4_11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Task411ApplicationTests {

	@Test
	void contextLoads() {
	}

}
